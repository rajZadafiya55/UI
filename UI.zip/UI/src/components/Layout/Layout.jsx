import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import Header from "../Header/Header";
import Router from "../../routes/Routers";

const Layout = () => {
  // const auth = localStorage.getItem("AdminData");
  return (
    <>
      <Header/>
      <Router/>
    </>
  )
};

export default Layout;
