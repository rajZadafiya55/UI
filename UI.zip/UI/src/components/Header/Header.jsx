import React from "react";
import { Link, useNavigate } from "react-router-dom";
import '../../Styles/header.css';

const Header = () => {
  const naviget = useNavigate();
  const auth = localStorage.getItem("AdminData");
  const logOut = () => {
    localStorage.clear();
    naviget("/register");
  };
  return (
    <div>
      <img src="https://www.logodee.com/wp-content/uploads/2020/07/LD-C-39.jpg" alt="logo" className="logo"/>
      { auth ? 
      <ul className="nav-ul">
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/foods">Foods</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/contact">Contact</Link>
        </li>
        <li>
            <Link to="/login" onClick={logOut}>Logout ({JSON.parse(auth).name})</Link>
        </li>
      </ul>
      : 
      <ul className="nav-ul nav-right">
        <li><Link to="/register">Register</Link></li>
          <li><Link to="/login">LogIn</Link></li>
      </ul>
}
    </div>
  );
};
export default Header;
