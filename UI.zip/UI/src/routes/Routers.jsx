// eslint-disable-next-line no-unused-vars
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from '../pages/Home';
import AllFoods from '../pages/AllFoods';

const Router = () => {
  return (
    <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/foods' element={<AllFoods/>}/>
    </Routes>
  )
}

export default Router