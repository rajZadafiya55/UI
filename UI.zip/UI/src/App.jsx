/* eslint-disable no-unused-vars */
import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Router from './routes/Routers';

function App() {
  return <Router/>
}

export default App
