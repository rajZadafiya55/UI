import { ADD_ITEM, DELETE_ITEM, ITEM_REQUECT } from "../Types/type";
import axios from 'axios';
import Swal from "sweetalert2";

const getItems = (items) => ({
    type: ITEM_REQUECT,
    payload: items
})

export const getItemsData = () => {
    return (dispatch) => {
        axios.get('http://localhost:5000/api/item/getAll')
            .then((res) => {
                dispatch(getItems(res.data.data))
            }).catch((error) => {
                console.log(error)
            })
    }
}

const addData = () => ({
    type: ADD_ITEM,
})

export const addItem = (data) => {
    console.log(data.imagename)
    return (dispatch) => {
 
        const formData = new FormData()
        formData.append('name', data.name)
        formData.append('price', data.price)
        formData.append('category', data.category)
        formData.append('rating', data.rating)
        formData.append('imagename', data.iamgename)

        axios.post("http://localhost:5000/api/item/add", formData)
            .then((res) => {
                dispatch(addData);
                dispatch(getItemsData());
                if(res.data.isSuccess === true){
                    Swal.fire({
                        position: 'center',
                            icon: 'success',
                            title: res.data.message,
                            showConfirmButton: false,
                            timer: 2500
                    })
                }else{
                    Swal.fire({
                        n: 'error',
                        title: 'Oops...',
                        text: res.data.message,
                        timer : 2500
                    })
                }
                console.log("data add successfully.")               
            }).catch((error) => {
                console.log(error)
            })
    }
}


const deleteData = (id) => ({
    type: DELETE_ITEM,
    payload:id
})

  