import { ITEM_REQUECT, ADD_ITEM } from "../Types/type";

const initialstate = {
    allItemsData: []
}

export const itemsReducer = (state = initialstate, actions) => {
    switch (actions.type) {
        case ITEM_REQUECT: {
            return { ...state, allItemsData: actions.payload };
        }
        case ADD_ITEM:
            return {...state}
        default: return state
    }

}