import {combineReducers} from "redux";
import { itemsReducer } from "./itemReducer";
const rootReducer = combineReducers({
    item:itemsReducer,
})

export default rootReducer;