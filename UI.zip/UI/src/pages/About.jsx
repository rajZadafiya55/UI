// eslint-disable-next-line no-unused-vars
import React from 'react'

const About = () => {
  return (
    <div>About</div>
  )
}

export default About