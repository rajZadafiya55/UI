// eslint-disable-next-line no-unused-vars
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addItem, getItemsData } from '../Redux/Actions/itemAction';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import { FaPenSquare, FaTrashAlt } from "react-icons/fa";
import '../Styles/AllFoods.css'

const AllFoods = () => {
  const [allItems, setAllItems] = useState([]);
  const [singleItem, setSingleItem] = useState({
    name: '',
    price: '',
    category: '',
    rating: '',
    imagename: '',
  })

  const resetData = {
    name: '',
    price: '',
    category: '',
    rating: '',
    imagename: '',
  }
  const dispatch = useDispatch();
  const items = useSelector(state => state.item.allItemsData);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    setAllItems(items)
  }, [items])

  useEffect(() => {
    dispatch(getItemsData())
  }, [])

  // form data 
  const getValues = (e) => {
    singleItem[e.target.name] = e.target.value;
    setSingleItem({ ...singleItem });
    console.log(singleItem.name);
  }

  const getPhoto = (e) => {
    setSingleItem({ ...singleItem, imagename: e.target.files })
  }

  const SubmitForm = (e) => {
    e.preventDefault();
    console.log(singleItem)
    dispatch(addItem(singleItem));
    handleClose();
    resetData();
  }
  return (
    <div>
      <Container>
        <div>
          <Button variant="dark" onClick={handleShow}>+ Add Items</Button>
        </div>

        {/* modal  */}
        <Modal
          size="lg"
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
          centered
        >
          <Modal.Header closeButton>
            <Modal.Title>Item Form </Modal.Title>
          </Modal.Header>
          <Modal.Body>

            {/* form  */}
            <Form onSubmit={SubmitForm}>
              <Row className="mb-3">
                <Form.Group as={Col} controlId="formGridName">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Item Name"
                    name='name'
                    onChange={getValues}
                  />
                </Form.Group>

                <Form.Group as={Col} controlId="formGridPrice">
                  <Form.Label>Price</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="Enter The Price"
                    name='price'
                    onChange={getValues}
                  />
                </Form.Group>
              </Row>

              <Row className="mb-3">
                <Form.Group as={Col} controlId="formGridCatgory">
                  <Form.Label>Category</Form.Label>
                  <Form.Select
                    defaultValue="dhosa"
                    name="category"
                    onChange={getValues}>
                    <option selected>Dhosa</option>
                    <option>Maxican</option>
                    <option>Italian</option>
                    <option>South</option>
                    <option>Drink</option>
                    <option>Combos</option>
                  </Form.Select>
                </Form.Group>

                <Form.Group as={Col} controlId="formGridRating">
                  <Form.Label>Rating</Form.Label>
                  <Form.Control
                    type="number"
                    placeholder="Enter  Rating"
                    name='rating'
                    onChange={getValues}
                  />
                </Form.Group>
              </Row>

              <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Select Item</Form.Label>
                <Form.Control
                  type="file"
                  
                  onChange={getPhoto}
                />

              </Form.Group>
              <img src={singleItem.imagename} alt='' />

              <Button type="submit" variant='danger' className='me-3'>Submit</Button>
              <Button type="button" variant='dark' onClick={handleClose}>Close</Button>
            </Form>
          </Modal.Body>
        </Modal>

        {/* Grid View  */}
        <Row>
          {
            allItems?.map((data, index) => {
              return (
                <Col key={index}>
                  <Card style={{ width: '17rem', height: '46vh', margin: '10px' }}>
                    <Card.Img variant="top" src={`/photos/${data.imagename}`} alt={data.imagename} height='140px' id='itemimages' />
                    <Card.Body>
                      <Card.Title>{data.name}</Card.Title>
                      <Card.Text>
                        Price : {data.price}<br />
                        rating : {data.rating}
                        <div className='mt-2'>
                          <FaPenSquare
                            style={{ fontSize: "30px" }}
                          />
                          <FaTrashAlt
                            style={{ fontSize: "25px" }}
                            className='ms-3'
                          />
                        </div>
                      </Card.Text>
                    </Card.Body>
                  </Card>
                </Col>
              )
            })
          }
        </Row>
      </Container>

    </div>
  )
}

export default AllFoods