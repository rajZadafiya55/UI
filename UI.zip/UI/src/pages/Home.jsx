// eslint-disable-next-line no-unused-vars
import React from 'react'


const Home = () => {

  return (
    <div>
     <h1>This is home page</h1>
    </div>
  )
}

export default Home